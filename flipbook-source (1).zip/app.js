(()=>{
'use strict';
const $=s=>document.querySelector(s);
const PRINT=location.hash==='#print';
const REDUCE=matchMedia('(prefers-reduced-motion:reduce)').matches;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const ease=p=>p<.5?4*p*p*p:1-Math.pow(-2*p+2,3)/2;          // easeInOutCubic
const PW=600,PH=840,R=PW/PH;

/* ---------- assets ---------- */
const POSTER=$('#poster').textContent.trim();
let VIDURL=null;
function videoURL(){
  if(VIDURL||PRINT||REDUCE)return VIDURL;
  try{const b=atob($('#vidb64').textContent.trim()),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);VIDURL=URL.createObjectURL(new Blob([u],{type:'video/webm'}))}catch(e){}
  return VIDURL;
}

/* ---------- decorate the page templates once ---------- */
const tpl=[...document.querySelectorAll('#pages > .pg')];
const NAMES=tpl.map(p=>p.dataset.title);
const ROMAN=['','I','II','III','IV','V','VI','VII','VIII','IX'];
function deco(i){
  const a=(i*53)%90,b=(i*29)%70;
  const P=[`M-20 ${150+a} C 120 ${30+b}, 260 ${330-a}, 640 ${100+b*1.5}`,
           `M-20 ${230+b} C 150 ${330-a}, 300 ${60+b}, 640 ${250-a}`,
           `M-20 ${90+a} C 180 ${200+b}, 330 ${20+a}, 640 ${190+b}`];
  return `<svg class="deco" viewBox="0 0 600 420" aria-hidden="true">`+P.map((d,k)=>`<path class="soft" d="${d}"/><path class="dash${k==1?' s2':''}" d="${d}" style="stroke-dashoffset:${k*30}"/>`).join('')+`</svg>`;
}
tpl.forEach((p,i)=>{
  p.querySelectorAll('[data-split]').forEach(el=>{
    const off=+el.dataset.off||0;let c=off;
    el.innerHTML=[...el.dataset.split].map(ch=>ch===' '?' ':`<span class="ch" style="--c:${c++}">${ch}</span>`).join('');
  });
  p.querySelectorAll('img[data-poster]').forEach(im=>im.src=POSTER);
  if(p.dataset.deco)p.insertAdjacentHTML('afterbegin',deco(i));
  if(i>0&&i<tpl.length-1){
    p.insertAdjacentHTML('beforeend','<i class="cn tl"></i><i class="cn tr"></i><i class="cn bl"></i><i class="cn br"></i>'+
      `<div class="folio"><span>AI Agent Orchestra</span><span>${String(i+1).padStart(2,'0')} · ${NAMES[i].split(' · ')[0]}</span></div>`);
  }
});

/* ---------- PRINT MODE (used to make the PDF) ---------- */
if(PRINT){
  document.documentElement.classList.add('print');
  document.documentElement.style.cssText='overflow:visible;height:auto';document.body.style.cssText='overflow:visible;height:auto;background:#06041a';
  const host=$('#pages');
  tpl.forEach(p=>{p.querySelectorAll('.vsheen').forEach(x=>x.remove())});
  document.fonts&&document.fonts.ready.then(()=>{document.title='ready';document.body.dataset.ready='1'});
  return;
}

/* ---------- state ---------- */
const stage=$('#stage'),Z=$('#zoom'),SH=$('#shift'),book=$('#book'),fx=$('#fx'),label=$('#label'),toc=$('#toc');
let mode='two',w=300,h=420,leaves=[],N=0,maxS=5,s=0,z=1,tx=0,ty=0,castL,castR,gl,gr,raf=0,peekOn=false;
let visSet=new Set(),visTimers=new Map();

function layout(){
  const W=stage.clientWidth,H=stage.clientHeight;
  const m=(W<720||W/H<.92)?'single':'two';
  const padX=W>900?96:(W>700?60:14),padT=W>700?40:46,padB=W>700?92:84;
  const aw=W-padX*2,ah=H-padT-padB;
  const ww=m==='two'?Math.min(aw/2,ah*R):Math.min(aw,ah*R);
  return {m,w:Math.max(120,Math.floor(ww)),padT,padB};
}
const visiblePages=()=>mode==='two'?(s===0?[0]:s===maxS?[9]:[2*s-1,2*s]):[s];
const toS=p=>mode==='two'?Math.ceil(p/2):p;
const toP=()=>mode==='two'?(s===0?0:s===maxS?9:2*s):s;

function mkFace(page,cls){
  const f=document.createElement('div');f.className='face '+cls;
  if(page==null){f.classList.add('blank');}
  else{
    const c=tpl[page].cloneNode(true);c.style.transform=`scale(${w/PW})`;c.dataset.p=page;
    c.querySelectorAll('.cover .vwrap, .vwrap').forEach(vw=>{if(page===0){const v=document.createElement('video');v.muted=true;v.loop=true;v.playsInline=true;v.setAttribute('playsinline','');v.preload='auto';v.setAttribute('muted','');const u=videoURL();if(u){v.src=u;vw.insertBefore(v,vw.querySelector('.vsheen'))}}});
    f.appendChild(c);
  }
  const sh=document.createElement('div');sh.className='sh';f.appendChild(sh);
  return f;
}
function build(keepAngles){
  const L=layout();mode=L.m;w=L.w;h=Math.round(w/R);
  const prevP=leaves.length?toPcache:0;
  book.innerHTML='';leaves=[];
  book.style.width=(w*2)+'px';book.style.height=h+'px';book.style.perspective=(w*3.4)+'px';
  gl=Object.assign(document.createElement('div'),{className:'gl'});gr=Object.assign(document.createElement('div'),{className:'gr'});
  for(const e of [gl,gr]){e.style.width=w+'px';e.style.height=h+'px'}
  castL=Object.assign(document.createElement('div'),{className:'cast castL'});castR=Object.assign(document.createElement('div'),{className:'cast castR'});
  for(const e of [castL,castR]){e.style.width=w+'px';e.style.height=h+'px'}
  book.append(gl,gr);
  if(mode==='two'){N=5;maxS=5;for(let k=0;k<5;k++)addLeaf(mkFace(2*k,'f'),mkFace(2*k+1,'b'),k===0||k===4)}
  else{N=10;maxS=9;for(let k=0;k<10;k++)addLeaf(mkFace(k,'f'),mkFace(null,'b'),false)}
  book.append(castL,castR);
  s=clamp(s,0,maxS);
  leaves.forEach((l,i)=>{l.a=i<s?180:0;});
  stage.style.paddingTop=0;
  Z.style.paddingTop=L.padT+'px';Z.style.paddingBottom=L.padB+'px';
  render();setVis(true);ui();applyZ(false);sizeFx();
}
let toPcache=0;
function addLeaf(front,back,hard){
  const el=document.createElement('div');el.className='leaf';el.style.width=w+'px';el.style.height=h+'px';
  front.style.width=back.style.width=w+'px';
  el.append(front,back);book.append(el);
  leaves.push({el,a:0,an:null,fs:front.querySelector('.sh'),bs:back.querySelector('.sh')});
}

/* ---------- rendering ---------- */
function paint(L,i){
  const a=L.a,sn=Math.sin(a*Math.PI/180);
  L.el.style.transform=a?`rotateY(${-a}deg)`:'';
  L.el.style.zIndex=(a>0&&a<180)?60+(a>90?i:N-i):(a>=90?i:N-i);
  L.fs.style.opacity=(sn*.42).toFixed(3);L.bs.style.opacity=(sn*.42).toFixed(3);
  L.el.style.visibility='visible';
}
function render(){
  if(raf){cancelAnimationFrame(raf);raf=0}
  const now=performance.now();let any=false,top=null,topS=0;
  leaves.forEach((L,i)=>{
    if(L.an){
      const p=(now-L.an.t0)/L.an.dur;
      if(p<0)any=true;
      else if(p>=1){L.a=L.an.to;L.an=null}
      else{L.a=L.an.from+(L.an.to-L.an.from)*ease(p);any=true}
    }
    paint(L,i);
    const sn=Math.sin(L.a*Math.PI/180);if(sn>topS){topS=sn;top=L}
  });
  /* book position + shadows */
  let sx=-w/2,gR=1,gL=0;
  if(mode==='two'){const f=leaves[0].a/180,l=leaves[N-1].a/180;sx=-w/2*(1-f)+w/2*l;gL=f;gR=1-l}
  else{gL=0;gR=1}
  SH.style.transform=`translateX(${sx.toFixed(1)}px)`;
  gr.style.opacity=gR.toFixed(3);gl.style.opacity=gL.toFixed(3);
  /* cast shadow of the turning leaf onto the page beneath */
  if(top&&topS>.02){
    const a=top.a,proj=w*Math.abs(Math.cos(a*Math.PI/180)),A=(.6*Math.pow(topS,.7)).toFixed(3);
    const g=dir=>`linear-gradient(${dir}deg,rgba(0,0,0,${A}) ${proj.toFixed(0)}px,rgba(0,0,0,0) ${(proj+w*.34).toFixed(0)}px)`;
    if(a<90){castR.style.background=g(90);castR.style.opacity=1;castL.style.opacity=0}
    else{castL.style.background=g(270);castL.style.opacity=1;castR.style.opacity=0}
  }else{castL.style.opacity=0;castR.style.opacity=0}
  if(any||drag)raf=requestAnimationFrame(render);else raf=0;
}
const kick=()=>{if(!raf)raf=requestAnimationFrame(render)};
function startAnim(L,to,delay,dur){
  if(Math.abs(L.a-to)<.01){L.an=null;return}
  L.an={from:L.a,to,t0:performance.now()+delay,dur:Math.max(REDUCE?1:280,dur*Math.abs(to-L.a)/180)};kick();
}

/* ---------- page visibility: triggers entrance animations + video ---------- */
function setVis(force){
  const want=new Set(visiblePages());
  document.querySelectorAll('.pg[data-p]').forEach(pg=>{
    const p=+pg.dataset.p,on=want.has(p);
    if(on){clearTimeout(visTimers.get(p));visTimers.delete(p);if(!pg.classList.contains('vis')||force)pg.classList.add('vis');
      const v=pg.querySelector('video');if(v)v.play&&v.play().catch(()=>{})}
    else if(pg.classList.contains('vis')&&!visTimers.has(p)){
      visTimers.set(p,setTimeout(()=>{pg.classList.remove('vis');visTimers.delete(p);const v=pg.querySelector('video');if(v)v.pause()},1300));
    }
  });
}

/* ---------- navigation ---------- */
function ui(){
  toPcache=toP();
  const vp=visiblePages();
  label.textContent=mode==='two'?(s===0?'Cover':s===maxS?'Back cover':`Pages ${2*s}–${2*s+1}`):(s===0?'Cover':s===maxS?'Back cover':`Page ${s+1} / 10`);
  for(const b of [$('#bp'),$('#sp')])b.disabled=s<=0;
  for(const b of [$('#bn'),$('#sn')])b.disabled=s>=maxS;
  $('#zo').disabled=z<=1.01;$('#zi').disabled=z>=4.99;
  toc.querySelectorAll('button').forEach((b,i)=>b.classList.toggle('on',vp.includes(i)));
}
function goto(t){
  t=clamp(t,0,maxS);if(t===s)return;
  hideHint();peek(false,true);
  const dir=t>s?1:-1,n=Math.abs(t-s),now=performance.now();
  const dur=n>1?760:1150,gap=n>1?105:0;
  for(let k=0;k<n;k++){const i=dir>0?s+k:s-1-k;startAnim(leaves[i],dir>0?180:0,k*gap,dur)}
  /* petals of light along the spine */
  burst(dir);
  s=t;setVis();ui();kick();
}
const go=d=>goto(s+d);
$('#bp').onclick=$('#sp').onclick=()=>go(-1);
$('#bn').onclick=$('#sn').onclick=()=>go(1);

/* peek: cover lifts slightly when you hover its edge */
function peek(on,force){
  if(s!==0||drag)return;
  const L=leaves[0];if(!L)return;
  if(on&&!peekOn&&!L.an){peekOn=true;startAnim(L,9,0,520)}
  else if(!on&&peekOn){peekOn=false;if(!force)startAnim(L,0,0,520);else L.an=null}
}

/* ---------- zoom & pan (never reset by page turns) ---------- */
function applyZ(sm){
  const sw=stage.clientWidth,sh=stage.clientHeight,bw=w*(mode==='two'?2:1),bh=h;
  const mx=Math.max(0,(bw*z-sw)/2)+50,my=Math.max(0,(bh*z-sh)/2)+50;
  tx=clamp(tx,-mx,mx);ty=clamp(ty,-my,my);
  Z.style.transition=sm?'transform .3s cubic-bezier(.2,.8,.2,1)':'none';
  Z.style.transform=`translate(${tx}px,${ty}px) scale(${z})`;
  stage.classList.toggle('zoomed',z>1.01);ui();
}
function zoomTo(nz,cx,cy,sm){
  nz=clamp(nz,1,5);
  if(nz<1.03){z=1;tx=ty=0}else{const k=nz/z;tx=cx-(cx-tx)*k;ty=cy-(cy-ty)*k;z=nz}
  applyZ(sm);
}
$('#zi').onclick=()=>zoomTo(z*1.5,0,0,true);
$('#zo').onclick=()=>zoomTo(z/1.5,0,0,true);
const rel=(x,y)=>{const r=stage.getBoundingClientRect();return[x-r.left-r.width/2,y-r.top-r.height/2]};

/* ---------- pointer: drag a page to turn it, pan when zoomed, pinch to zoom ---------- */
const ptr=new Map();let drag=null,pinch=null,pinched=false,down=null,tap={t:0,x:0,y:0},lastTog=0,vel=[];
const skipT=e=>e.target.closest&&e.target.closest('#bar,#toc,.side,#hint');
stage.addEventListener('pointerdown',e=>{
  if(skipT(e))return;
  ptr.set(e.pointerId,{x:e.clientX,y:e.clientY});down={x:e.clientX,y:e.clientY,t:performance.now(),moved:false};vel=[];
  try{stage.setPointerCapture(e.pointerId)}catch(_){}
  if(ptr.size===2){
    const[a,b]=[...ptr.values()];pinched=true;
    if(drag)cancelDrag();
    pinch={d:Math.hypot(a.x-b.x,a.y-b.y)||1,z0:z,mx:(a.x+b.x)/2,my:(a.y+b.y)/2};
  }
});
stage.addEventListener('pointermove',e=>{
  const p=ptr.get(e.pointerId);
  if(!p){ /* hover */
    if(e.pointerType==='mouse'){const r=book.getBoundingClientRect();peek(s===0&&z<=1.01&&e.clientX>r.left+r.width*.62&&e.clientX<r.right+40);trail(e.clientX,e.clientY)}
    return;
  }
  const dx=e.clientX-p.x,dy=e.clientY-p.y;p.x=e.clientX;p.y=e.clientY;
  vel.push({x:e.clientX,t:performance.now()});if(vel.length>6)vel.shift();
  if(ptr.size===2&&pinch){
    const[a,b]=[...ptr.values()],d=Math.hypot(a.x-b.x,a.y-b.y),mx=(a.x+b.x)/2,my=(a.y+b.y)/2;
    tx+=mx-pinch.mx;ty+=my-pinch.my;pinch.mx=mx;pinch.my=my;
    const[c,k]=rel(mx,my);zoomTo(pinch.z0*d/pinch.d,c,k,false);return;
  }
  if(ptr.size!==1||!down)return;
  const tdx=e.clientX-down.x,tdy=e.clientY-down.y;
  if(Math.hypot(tdx,tdy)>8)down.moved=true;
  if(z>1.01){tx+=dx;ty+=dy;applyZ(false);return}
  if(!drag&&down.moved&&Math.abs(tdx)>Math.abs(tdy)*.8){
    const dir=tdx<0?1:-1;
    if((dir>0&&s<maxS)||(dir<0&&s>0)){
      const i=dir>0?s:s-1,L=leaves[i];
      peekOn=false;L.an=null;hideHint();
      drag={dir,i,L,x0:down.x};setVisFor(dir);
    }
  }
  if(drag){
    const prog=clamp(Math.abs(e.clientX-drag.x0)/(w*1.35*z),0,1);
    drag.prog=prog;
    drag.L.a=drag.dir>0?prog*180:180-prog*180;
    kick();
  }
});
function setVisFor(dir){ /* pre-activate the pages that will be revealed */
  const t=clamp(s+dir,0,maxS),keep=s;s=t;setVis();s=keep;
}
function cancelDrag(){if(!drag)return;const L=drag.L;startAnim(L,drag.dir>0?0:180,0,700);drag=null;setVis();kick()}
function endPtr(e){
  if(!ptr.has(e.pointerId))return;
  ptr.delete(e.pointerId);if(ptr.size<2)pinch=null;
  const wasPinch=pinched;if(ptr.size===0)pinched=false;
  try{stage.releasePointerCapture(e.pointerId)}catch(_){}
  if(drag){
    const L=drag.L,dir=drag.dir,v=velocity();
    const fast=dir>0?v<-.45:v>.45,done=e.type==='pointerup'&&(drag.prog>.28||fast)&&!(dir>0?v>.6:v<-.6);
    const to=done?(dir>0?180:0):(dir>0?0:180);
    startAnim(L,to,0,900);
    if(done){s=clamp(s+dir,0,maxS);burst(dir)}
    drag=null;setVis();ui();kick();return;
  }
  if(e.type==='pointerup'&&!wasPinch&&down&&!down.moved&&performance.now()-down.t<500){
    const now=performance.now();
    if(now-tap.t<320&&Math.hypot(e.clientX-tap.x,e.clientY-tap.y)<40){toggleZoom(e.clientX,e.clientY);tap.t=0;return}
    tap={t:now,x:e.clientX,y:e.clientY};
    /* single tap on the outer thirds turns the page (only when not zoomed) */
    const r=stage.getBoundingClientRect(),fx_=(e.clientX-r.left)/r.width;
    setTimeout(()=>{if(tap.t===now&&z<=1.01){if(fx_>.7)go(1);else if(fx_<.3)go(-1);else if(s===0)go(1)}},330);
  }
}
function velocity(){if(vel.length<2)return 0;const a=vel[0],b=vel[vel.length-1];return(b.x-a.x)/Math.max(1,b.t-a.t)}
stage.addEventListener('pointerup',endPtr);stage.addEventListener('pointercancel',endPtr);
stage.addEventListener('pointerleave',e=>{if(e.pointerType==='mouse')peek(false)});
function toggleZoom(x,y){
  if(performance.now()-lastTog<400)return;lastTog=performance.now();
  const[c,d]=rel(x,y);z>1.05?zoomTo(1,0,0,true):zoomTo(2.4,c,d,true);
}
stage.addEventListener('dblclick',e=>{if(!skipT(e))toggleZoom(e.clientX,e.clientY)});
stage.addEventListener('wheel',e=>{
  if(skipT(e))return;e.preventDefault();
  if(e.ctrlKey||e.metaKey){const[c,d]=rel(e.clientX,e.clientY);zoomTo(z*Math.exp(-e.deltaY*.01),c,d,false)}
  else if(z>1.01){tx-=e.deltaX;ty-=e.deltaY;applyZ(false)}
  else if(Math.abs(e.deltaX)>Math.abs(e.deltaY)){if(Math.abs(e.deltaX)>30&&!wheelLock){wheelLock=1;go(e.deltaX>0?1:-1);setTimeout(()=>wheelLock=0,900)}}
},{passive:false});
let wheelLock=0;
['gesturestart','gesturechange'].forEach(t=>document.addEventListener(t,e=>e.preventDefault()));

/* ---------- toc, fullscreen, keyboard ---------- */
NAMES.forEach((n,i)=>{
  const b=document.createElement('button');b.innerHTML=`<em>${i===0?'':ROMAN[i]||i}</em><span>${n}</span>`;
  b.onclick=()=>{toc.classList.remove('open');$('#bc').classList.remove('on');goto(toS(i))};toc.appendChild(b);
});
$('#bc').onclick=()=>{const o=toc.classList.toggle('open');$('#bc').classList.toggle('on',o)};
if(!(document.fullscreenEnabled||document.webkitFullscreenEnabled))$('#fs').hidden=true;
$('#fs').onclick=()=>{const d=document,el=d.documentElement;(d.fullscreenElement||d.webkitFullscreenElement)?(d.exitFullscreen||d.webkitExitFullscreen).call(d):(el.requestFullscreen||el.webkitRequestFullscreen).call(el)};
addEventListener('keydown',e=>{
  const k=e.key;
  if(k==='ArrowRight'||k==='PageDown'||k===' ')go(1);
  else if(k==='ArrowLeft'||k==='PageUp')go(-1);
  else if(k==='Home')goto(0);else if(k==='End')goto(maxS);
  else if(k==='+'||k==='=')$('#zi').click();else if(k==='-')$('#zo').click();
  else if(k==='0')zoomTo(1,0,0,true);
  else if(k==='f'||k==='F')$('#fs').click();
  else if(k==='Escape'){toc.classList.remove('open');$('#bc').classList.remove('on')}
  if(k===' ')e.preventDefault();
});
document.addEventListener('pointerdown',e=>{if(toc.classList.contains('open')&&!e.target.closest('#toc,#bc')){toc.classList.remove('open');$('#bc').classList.remove('on')}},true);
const hint=$('#hint');function hideHint(){hint.classList.add('out')}
setTimeout(hideHint,7000);

/* ---------- resize (keeps zoom + page) ---------- */
let rt;
function onResize(){clearTimeout(rt);rt=setTimeout(()=>{
  const keepP=toPcache,old=mode,L=layout();
  if(L.m!==old){s=L.m==='two'?Math.ceil(keepP/2):keepP}
  if(L.m!==old||Math.abs(L.w-w)>1){build()}else{applyZ(false)}
},120)}
addEventListener('resize',onResize);addEventListener('orientationchange',onResize);

/* =====================================================================
   ETHEREAL LAYER: notes, code, petals, fireflies, silk threads
   ===================================================================== */
const ctx=fx.getContext('2d');let FW=0,FH=0,DPR=1,parts=[],sprites={},threads=[],fxVis=true,tprev=performance.now(),mouse={x:-999,y:-999,t:0};
const COLS=['#35e4f4','#8b5cf6','#62f4ae','#d9ccff','#ffc9df'];
function makeSprites(){
  const S=96;
  const note=(kind,col)=>{
    const c=document.createElement('canvas');c.width=c.height=S;const g=c.getContext('2d');
    g.translate(S/2-4,S/2+14);g.scale(S/3.1,S/3.1);g.shadowColor=col;g.shadowBlur=22;g.fillStyle=col;
    const head=(x)=>{g.beginPath();g.ellipse(x,0,.36,.25,-.45,0,7);g.fill()};
    const stem=(x)=>g.fillRect(x+.26,-1.6,.075,1.6);
    if(kind===0){head(0);stem(0)}
    else if(kind===1){head(0);stem(0);g.beginPath();g.moveTo(.335,-1.6);g.bezierCurveTo(.8,-1.35,.95,-.95,.7,-.5);g.bezierCurveTo(.78,-.95,.6,-1.15,.335,-1.1);g.fill()}
    else{head(-.45);head(.5);stem(-.45);stem(.5);g.beginPath();g.moveTo(-.19,-1.6);g.lineTo(.84,-1.6);g.lineTo(.84,-1.3);g.lineTo(-.19,-1.3);g.fill()}
    return c;
  };
  const text=(t,col)=>{
    const c=document.createElement('canvas');c.width=220;c.height=48;const g=c.getContext('2d');
    g.font='500 22px "DejaVu Sans Mono",ui-monospace,Menlo,Consolas,monospace';g.textBaseline='middle';g.shadowColor=col;g.shadowBlur=12;g.fillStyle=col;g.fillText(t,10,24);
    const m=g.measureText(t).width;c.tw=m+20;return c;
  };
  const glow=(col)=>{const c=document.createElement('canvas');c.width=c.height=48;const g=c.getContext('2d');const gr=g.createRadialGradient(24,24,0,24,24,24);gr.addColorStop(0,'#fff');gr.addColorStop(.2,col);gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(0,0,48,48);return c};
  sprites.notes=[];COLS.forEach(c=>[0,1,2].forEach(k=>sprites.notes.push(note(k,c))));
  const T=['</>','{ }','=>','agent()','prompt','n8n','if/else','async','0101','await','tool()','trigger'];
  sprites.text=T.map((t,i)=>text(t,COLS[i%3]));
  sprites.glow=COLS.map(glow);
}
function sizeFx(){
  const r=stage.getBoundingClientRect();DPR=Math.min(devicePixelRatio||1,2);
  FW=r.width;FH=r.height;fx.width=FW*DPR;fx.height=FH*DPR;ctx.setTransform(DPR,0,0,DPR,0,0);
  seedThreads();
}
function seedThreads(){
  threads=Array.from({length:4},(_,i)=>({y:.15+i*.22,ph:Math.random()*6,sp:.12+Math.random()*.12,amp:.1+Math.random()*.1,col:i===2?'255,92,122':(i%2?'185,164,255':'53,228,244'),a:i===2?.34:.2}));
}
const rnd=(a,b)=>a+Math.random()*(b-a);
function spawn(kind,init){
  const p={kind,ph:rnd(0,6.28),life:1};
  if(kind==='note'){p.s=sprites.notes[(Math.random()*sprites.notes.length)|0];p.x=rnd(-.05,1.05)*FW;p.y=init?rnd(0,FH):FH+40;p.vx=rnd(10,34);p.vy=-rnd(22,56);p.rot=rnd(-.5,.5);p.vr=rnd(-.4,.4);p.sz=rnd(26,56);p.al=rnd(.45,.85);p.sw=rnd(14,36)}
  else if(kind==='code'){p.s=sprites.text[(Math.random()*sprites.text.length)|0];p.x=init?rnd(0,FW):-p.s.tw;p.y=rnd(.05,.95)*FH;p.vx=rnd(26,70);p.vy=rnd(-6,6);p.rot=0;p.vr=0;p.sz=rnd(.55,.85);p.al=rnd(.22,.5);p.sw=rnd(6,16)}
  else if(kind==='petal'){p.x=rnd(-.1,1.1)*FW;p.y=init?rnd(0,FH):-30;p.vx=rnd(14,40);p.vy=rnd(26,58);p.rot=rnd(0,6.28);p.vr=rnd(-1.4,1.4);p.sz=rnd(6,12);p.al=rnd(.45,.8);p.sw=rnd(18,44);p.c=Math.random()<.78?'255,201,223':'255,255,255'}
  else{p.s=sprites.glow[(Math.random()*5)|0];p.x=rnd(0,FW);p.y=rnd(0,FH);p.vx=rnd(-8,8);p.vy=rnd(-10,4);p.sz=rnd(5,13);p.al=rnd(.4,.9);p.sw=rnd(10,30);p.tw=rnd(.6,1.8)}
  return p;
}
function seedParts(){
  const area=FW*FH,n=clamp(area/36000,16,64)*(innerWidth<700?.7:1);
  parts=[];
  for(let i=0;i<n*.34;i++)parts.push(spawn('note',true));
  for(let i=0;i<n*.26;i++)parts.push(spawn('code',true));
  for(let i=0;i<n*.3;i++)parts.push(spawn('petal',true));
  for(let i=0;i<n*.4;i++)parts.push(spawn('fly',true));
}
function burst(dir){
  if(REDUCE)return;
  const r=book.getBoundingClientRect(),sr=stage.getBoundingClientRect();
  const x=r.left+r.width/2-sr.left,y=r.top-sr.top+r.height*.5;
  for(let i=0;i<26;i++){
    const a=rnd(-1.2,1.2)+(dir>0?Math.PI:0),sp=rnd(60,220);
    const p=i%3===0?spawn('note'):i%3===1?spawn('petal'):spawn('fly');
    p.x=x+rnd(-8,8);p.y=y+rnd(-h*.42,h*.42);p.vx=Math.cos(a)*sp;p.vy=Math.sin(a)*sp*.6-rnd(0,50);p.burst=1.4;p.al=Math.min(1,(p.al||.7)+.2);
    parts.push(p);
  }
  if(parts.length>150)parts.splice(0,parts.length-150);
}
function trail(x,y){
  if(REDUCE)return;const now=performance.now();if(now-mouse.t<46)return;mouse.t=now;
  const sr=stage.getBoundingClientRect();
  const p=spawn('fly');p.x=x-sr.left;p.y=y-sr.top;p.vx=rnd(-14,14);p.vy=rnd(-30,-6);p.sz=rnd(4,9);p.burst=.9;p.al=.9;parts.push(p);
  mouse.x=p.x;mouse.y=p.y;if(parts.length>150)parts.shift();
}
function drawPetal(p){
  ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.rot);const f=Math.abs(Math.sin(p.ph*1.3));ctx.scale(1,.35+.65*f);
  ctx.fillStyle=`rgba(${p.c},${p.al*.8})`;ctx.beginPath();ctx.moveTo(0,-p.sz);ctx.bezierCurveTo(p.sz*.9,-p.sz*.6,p.sz*.8,p.sz*.5,0,p.sz);ctx.bezierCurveTo(-p.sz*.8,p.sz*.5,-p.sz*.9,-p.sz*.6,0,-p.sz);ctx.fill();ctx.restore();
}
function frame(now){
  requestAnimationFrame(frame);
  if(!fxVis||document.hidden)return;
  const dt=Math.min((now-tprev)/1000,.05);tprev=now;const t=now/1000;
  ctx.clearRect(0,0,FW,FH);ctx.globalCompositeOperation='lighter';
  /* silk threads */
  ctx.lineWidth=1.1;
  for(const th of threads){
    ctx.strokeStyle=`rgba(${th.col},${th.a})`;ctx.beginPath();
    for(let x=-10;x<=FW+10;x+=16){
      const y=FH*th.y+Math.sin(x*.008+t*th.sp*3+th.ph)*FH*th.amp+Math.sin(x*.019-t*th.sp*2+th.ph*2)*FH*.03;
      x===-10?ctx.moveTo(x,y):ctx.lineTo(x,y);
    }
    ctx.stroke();
  }
  for(let i=parts.length-1;i>=0;i--){
    const p=parts[i];
    p.ph+=dt*(p.kind==='petal'?2.2:1.1);
    const wob=Math.sin(p.ph+t*.6)*p.sw;
    p.x+=(p.vx+(p.kind==='petal'?wob*.6:wob*.35))*dt;p.y+=(p.vy+(p.kind==='note'?Math.cos(p.ph)*10:0))*dt;p.rot+=(p.vr||0)*dt;
    if(p.burst){p.burst-=dt;p.vx*=.97;p.vy*=.97;p.vy+=20*dt;if(p.burst<=0){parts.splice(i,1);continue}}
    let a=p.al;if(p.burst)a*=Math.min(1,p.burst);
    /* fade near edges */
    const out=p.x<-120||p.x>FW+120||p.y<-80||p.y>FH+80;
    if(out&&!p.burst){parts[i]=spawn(p.kind,false);continue}
    if(p.kind==='note'){ctx.globalAlpha=a*clamp(p.y/(FH*.25),0,1)*clamp((FH-p.y+60)/120,0,1);ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.rot+Math.sin(p.ph)*.18);ctx.drawImage(p.s,-p.sz/2,-p.sz/2,p.sz,p.sz);ctx.restore()}
    else if(p.kind==='code'){ctx.globalAlpha=a*Math.sin(Math.PI*clamp((p.x+p.s.tw)/(FW+p.s.tw*2),0,1));ctx.drawImage(p.s,p.x,p.y+Math.sin(p.ph)*6,p.s.width*p.sz,p.s.height*p.sz)}
    else if(p.kind==='petal'){ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';drawPetal(p);ctx.globalCompositeOperation='lighter'}
    else{const tw=.5+.5*Math.sin(p.ph*(p.tw||1.5)*2);ctx.globalAlpha=a*(.35+.65*tw);ctx.drawImage(p.s,p.x-p.sz*1.5,p.y-p.sz*1.5,p.sz*3,p.sz*3)}
  }
  ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
}
makeSprites();

/* ---------- boot ---------- */
build();
sizeFx();seedParts();
if(!REDUCE)requestAnimationFrame(frame);
else{ /* one still frame of the effects */ frame(performance.now());}
new ResizeObserver(()=>{sizeFx();seedParts()}).observe(stage);
document.addEventListener('visibilitychange',()=>{tprev=performance.now()});
setVis(true);
})();
