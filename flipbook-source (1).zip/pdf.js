const {chromium}=require('playwright');
(async()=>{
 const b=await chromium.launch();const p=await b.newPage({viewport:{width:600,height:840}});
 p.on('pageerror',e=>console.log('pageerror',e.message));
 await p.goto('file://'+__dirname+'/dist/AI-Agent-Orchestra-Participants-Flipbook.html#print');
 await p.waitForSelector('body[data-ready="1"]');await p.waitForTimeout(800);
 await p.emulateMedia({media:'print'});
 await p.pdf({path:'dist/AI-Agent-Orchestra-Participants-Guide.pdf',width:'600px',height:'840px',printBackground:true,margin:{top:0,right:0,bottom:0,left:0},preferCSSPageSize:true});
 await b.close();})();
